﻿function Lepro() {
    var self = this;
    self.refresh();

    window.setInterval(function() {
        self.refresh()
    }, self._refreshTimeout);
}

Lepro.prototype = {

    _refreshTimeout: 60*1000*5, // 5 mins
    _feedUrl: 'http://leprosorium.ru/api/lepropanel',

    _setUnreadCount: function(data) {

        kango.console.log( data );

        kango.invokeAsync('kango.storage.getItem', 'main::badge', function( badge ){

            var string = '';
            var count = 0;

            switch( badge )
            {
                case 1:
                    string = 'Карма';
                    count = data.response.karma;
                    break;
                case 2:
                    string = 'Рейтинг';
                    count = data.response.rating;
                    break;
                case 3:
                    string = "Посты";
                    count = data.response.myunreadposts;
                    break;
                case 4:
                    string = "Комменты";
                    count = data.response.myunreadcomms;
                    break;
                case 5:
                    string = "Инбоксы";
                    count = data.response.inboxunreadposts;
                    break;
                case 6:
                    string = "В инбоксах";
                    count = data.response.inboxunreadcomms;
                    break;
                default:
                    string = '';
                    count = 0;

            }

            kango.console.log( string );
            kango.console.log( count );

            var split = string + ': ' + count;

            if( badge = 0 )
            {
                split = ''
            }

            kango.ui.browserButton.setTooltipText( split );
            kango.ui.browserButton.setIcon('icons/button.png');
            kango.ui.browserButton.setBadgeValue(count);



        });

    },

    refresh: function() {
        var details = {
            url: 'http://leprosorium.ru/api/lepropanel',
            method: 'GET',
            async: true,
            contentType: 'json'
        };

        var self = this;


        kango.xhr.send(details, function(data) {
            if (data.status == 200 && data.response != null) {

                self._setUnreadCount(data);
            }
        });
    }

};

var extension = new Lepro();

kango.addMessageListener('refresh', function(event) {
    extension.refresh();
});